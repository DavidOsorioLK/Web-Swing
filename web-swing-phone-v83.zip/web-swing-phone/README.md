# Web Swing Phone

Prototipo HTML del juego Web Swing (Spider-Man). Punto de partida: v83.

## Cómo probarlo
Abrir `index.html` en el navegador (todo va incrustado en el archivo).

## Flujo de trabajo
- `main` = versión integrada. Nadie trabaja directamente en `main`.
- Una rama por persona y mejora: `david/<mejora>`, `manu/<mejora>`.
- Los cambios entran en `main` mediante pull request.
- Cada versión de prueba se publica como artefacto nuevo y numerado (v84, v85…), sin sobrescribir los anteriores.
- El artefacto "oficial" solo lo actualiza una persona, siempre desde `main`.

## Reparto de zonas (a acordar)
- David: …
- Manu: …
